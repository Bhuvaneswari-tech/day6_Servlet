package com.example.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		
		resp.setContentType("text/html");
		
		if("admin".equals(name) && "admin123".equals(password)) {
			Cookie ck = new Cookie("username",name);
			
			ck.setMaxAge(60*60);
			
			resp.addCookie(ck);
			
			resp.sendRedirect("ProfileServlet");
		}
		
		else {
			resp.getWriter().println("Invalid Credentials.<br>");
			req.getRequestDispatcher("login.jsp").include(req,resp);
		}
	}
}
