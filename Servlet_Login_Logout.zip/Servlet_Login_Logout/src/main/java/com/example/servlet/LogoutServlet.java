package com.example.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Cookie[] cookies = req.getCookies();
		if(cookies !=null) {
			for(Cookie ck: cookies) {
				if("username".equals(ck.getName())) {
					ck.setMaxAge(0); //delete Cookie
					resp.addCookie(ck);
				}
			}
		}
		
		resp.setContentType("text/html");
        resp.getWriter().println("<h2>You have been logged out successfully.</h2>");
        resp.getWriter().println("<a href='login.jsp'>Login Again</a>");
	}
	

}
