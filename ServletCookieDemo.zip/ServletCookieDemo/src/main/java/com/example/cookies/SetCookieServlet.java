package com.example.cookies;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/setCookie")
public class SetCookieServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Create Cookie
		Cookie userCookie = new Cookie("username", "BhuvaneswariJakartaUser");
		
		//Set expiry to 1 day
		userCookie.setMaxAge(24*60*60);
		
		//Add Cookie to response
		resp.addCookie(userCookie);
		
		resp.setContentType("text/html");
		resp.getWriter().println("<h3>Cookie has been set!</h3>");
		resp.getWriter().println("<a href='readCookie'>Click here to read Cookie</a>");
		
	}
}
