package com.example.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		
		Cookie[] cookies = req.getCookies();
		
		String name = null;
		
		if(cookies != null) {
			for(Cookie ck: cookies) {
				if("username".equals(ck.getName())) {
					name=ck.getValue();
				}
			}
		}
		
		if(name != null) {
			resp.getWriter().println("<h2>Welcome , "+name+"!</h2>");
			resp.getWriter().println("<form action='LogoutServlet' method='get'>");
			resp.getWriter().println("<input type='submit' value='Logout'>");
			resp.getWriter().println("</form>");
			
		}
		else {
			resp.getWriter().println("<h3>Please login first.</h3>");
			resp.getWriter().println("<a href='login.jsp'>Login</a>");
		}
	}

}