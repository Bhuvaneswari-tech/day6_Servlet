package com.example.filter;


import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;

@WebFilter("/ProfileServlet")
public class AuthFilter implements Filter{

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;
		
		Cookie[] cookies = request.getCookies();
		boolean loggedIn = false;
		
		if(cookies !=null) {
			for(Cookie c: cookies) {
				if(c.getName().equals("username") && !c.getValue().isEmpty()){
					loggedIn=true;
				}
			}
		}
		if(loggedIn) {
			chain.doFilter(req, res);
		}
		else {
			res.getWriter().println("<h3>You must login first.</h3>");
			res.getWriter().println("<a href='login.jsp'>Login</a>");
		}
	}

	

}
